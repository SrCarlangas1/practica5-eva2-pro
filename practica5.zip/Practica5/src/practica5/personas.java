

package practica5;

import java.util.Scanner;


public class personas {
    private String nombre;
    private String apellidos;
    private String DNI;
    private String Cargo;
    private int num_personas;
    static public int num_personas_totales;

    public personas() {
    }

    public personas(String nombre, String apellidos, String DNI, String Cargo) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI = DNI;
        this.Cargo = Cargo;
    }

    
    
/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getDNI() {
        return DNI;
    }

    public String getCargo() {
        return Cargo;
    }
        
    public int getNum_personas() {
        return num_personas;
    }


    
    
/*------------Los Seters---------------------*/
/*----------------------------------------------------------------------------*/
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }
 
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
    
    
    static public personas crear_Personas(){
        Scanner lector=new Scanner(System.in);
        personas persona=new personas();        
        System.out.println("======================");
        System.out.println("CREAR LIBRO... ");
        System.out.println("----------------------");
        System.out.println("¿Introduce un nombre?");
        persona.setNombre(lector.nextLine());      
        System.out.println("¿Introduce los apellidos?");
        persona.setApellidos(lector.nextLine());
        System.out.println("¿Introduce un DNI?");
        persona.setDNI(lector.nextLine());        
        System.out.println("¿Introduce un cargo?");
        persona.setCargo(lector.nextLine());        
        return persona;    
    } 
}
