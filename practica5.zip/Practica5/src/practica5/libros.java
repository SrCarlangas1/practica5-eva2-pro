
package practica5;

import java.util.ArrayList;
import java.util.Scanner;


public class libros {

    static String setNum_ejem_prestados_glob() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private String titulo;
    private String autor;  
    private int isbn;  
    private int num_ejem_prestados;
    private int num_ejem_totales;    
    static public int num_ejem_prestados_glob;
    static public int num_ejem_totales_glob;

    public libros(String titulo, String autor, int isbn, int num_ejem_prestados, int num_ejem_totales) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.num_ejem_prestados = num_ejem_prestados;
        this.num_ejem_totales = num_ejem_totales;
    }

    public libros() {
    }

/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getIsbn() {
        return isbn;
    }

    public int getNum_ejem_prestados() {
        return num_ejem_prestados;
    }

    public int getNum_ejem_totales() {
        return num_ejem_totales;
    }

    public static int getNum_ejem_prestados_glob() {
        return num_ejem_prestados_glob;
    }

    public static int getNum_ejem_totales_glob() {
        return num_ejem_totales_glob;
    }
/*----------------------------------------------------------------------------*/
/*------------Los Seters---------------------*/
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setIsbn(int isbn) {
        this.isbn = isbn;
    }

    public void setNum_ejem_prestados(int num_ejem_prestados) {
        this.num_ejem_prestados = num_ejem_prestados;
    }

    public void setNum_ejem_totales(int num_ejem_totales) {
        this.num_ejem_totales = num_ejem_totales;
    }

    public static void setNum_ejem_prestados_glob(int num_ejem_prestados_glob) {
        libros.num_ejem_prestados_glob = num_ejem_prestados_glob;
    }

    public static void setNum_ejem_totales_glob(int num_ejem_totales_glob) {
        libros.num_ejem_totales_glob = num_ejem_totales_glob;
    }
/*----------------------------------------------------------------------------*/  
/*----------------------------------------------------------------------------*/
    
    
    
  static public libros crear_Libros(){
        Scanner lector=new Scanner(System.in);
        libros libro=new libros();        
        System.out.println("======================");
        System.out.println("CREAR LIBRO... ");
        System.out.println("----------------------");
        System.out.println("¿Introduce el TITULO del libro?");
        libro.setTitulo(lector.nextLine());      
        System.out.println("¿Introduce el AUTOR del libro?");
        libro.setAutor(lector.nextLine());
        System.out.println("¿Introduce el ISBN del libro?");
        libro.setIsbn(lector.nextInt());        
        System.out.println("¿Introduce el NÚMERO DE EJEMPLARES TOTALES del libro?");
        libro.setNum_ejem_totales(lector.nextInt()); 
        libro.setNum_ejem_prestados(0);
        return libro;    
    }    
   public void mostrar_Libro(){
        System.out.println("======================");
        System.out.println("FICHA DEL LIBRO       ");
        System.out.println("----------------------");
        System.out.println("Titulo: "+ this.titulo);
        System.out.println("Autor: "+ this.autor);
        System.out.println("======================");        
    }
}
