/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica5;

import java.util.ArrayList;
import java.util.Scanner;


public class bibliotecas {
    
    private int id;
    private String nombre;
    private String direcion;
    private ArrayList <libros> listalibros;
    private ArrayList <personas> listapersonas;

    public bibliotecas(int id, String nombre, String direcion, ArrayList libros, ArrayList personas) {
        this.id = id;
        this.nombre = nombre;
        this.direcion = direcion;
        this.listalibros = libros;
        this.listapersonas = personas;
    }

    public bibliotecas() {
    }
    
    
    
/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDirecion() {
        return direcion;
    }

    public ArrayList getLibros() {
        return listalibros;
    }

    public ArrayList getPersonas() {
        return listapersonas;
    }
/*---------------Los Seters------------------*/
/*----------------------------------------------------------------------------*/
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDirecion(String direcion) {
        this.direcion = direcion;
    }

    public void setLibros(ArrayList libros) {
        this.listalibros = libros;
    }

    public void setPersonas(ArrayList personas) {
        this.listapersonas = personas;
    }
/*----------------------------------------------------------------------------*/    
/*----------------------------------------------------------------------------*/   
/*Para crear la bliblioteca*/    
    static public bibliotecas crear_Biblioteca(){
        Scanner lectoria=new Scanner(System.in);
        bibliotecas biblio=new bibliotecas();        
        System.out.println("======================");
        System.out.println("Crear biblioteca");
        System.out.println("----------------------");
        System.out.println("¿Introduce id?");
        biblio.setId(lectoria.nextInt());      
        System.out.println("¿Introduce nombre?");
        biblio.setNombre(lectoria.nextLine());
        System.out.println("¿Introduce dirección?");
        biblio.setDirecion(lectoria.nextLine());
        ArrayList<libros> lista_libros =new ArrayList<>();
        biblio.setLibros(lista_libros);
        ArrayList<personas> lista_personas =new ArrayList<>();
        biblio.setPersonas(lista_personas);
        return biblio;    
    }    
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Añadir libro en la biblioteca*/    
    public void añadir_libro(libros pepe){
        this.listalibros.add(pepe);
        
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/    
/*Añadir persona en la biblioteca*/    
    public void añadir_persona(personas pepa){
        this.listapersonas.add(pepa);
        
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/    
/*Localizar biblioteca y crear los libos*/
    static public void localizar_Biblioteca_libro(ArrayList<bibliotecas> b){
        
        Scanner lector=new Scanner(System.in);
        System.out.println("======================");
        System.out.println("Indica la biblioteca ");
        System.out.println("----------------------");
        System.out.println("Introduce la ID de la biblioteca");
        int c=lector.nextInt();
        boolean encontrado=false;
        int i = 0;
        while ((i < b.size()) && (encontrado==false)) {
            if (b.get(i).getId()==c){
                System.out.println("La biblioteca existe, indica las caracteristicas del libro");
                b.get(i).añadir_libro(libros.crear_Libros());
                encontrado=true; 
            }else i++;            
        }
        if (encontrado==false){
            System.out.println("La biblioteca no existe");            
        }         
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Para mostar la biblioteca*/
    
    public void mostrar_Biblioteca(){
        System.out.println("======================");
        System.out.println("Ficha biblioteca      ");
        System.out.println("----------------------");
        System.out.println("Id: "+ this.getId());
        System.out.println("Nombre: "+ this.getNombre());
        System.out.println("Dirección: "+this.getDirecion());
        System.out.println("Libros prestados: "+libros.setNum_ejem_prestados_glob());
        System.out.println("Personas responsables: ");
        System.out.println("======================"); 
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Localizar biblioteca y crear los pèrsonas*/
    static public void localizar_Biblioteca_persona(ArrayList<bibliotecas> b){
        
        Scanner lector=new Scanner(System.in);
        System.out.println("======================");
        System.out.println("Indica la biblioteca ");
        System.out.println("----------------------");
        System.out.println("Introduce la ID de la biblioteca");
        int c=lector.nextInt();
        boolean encontrado=false;
        int i = 0;
        while ((i < b.size()) && (encontrado==false)) {
            if (b.get(i).getId()==c){
                System.out.println("La biblioteca existe, indica las caracteristicas de la persona");
                b.get(i).añadir_persona(personas.crear_Personas());
                encontrado=true; 
            }else i++;            
        }
        if (encontrado==false){
            System.out.println("La biblioteca no existe");            
        }   
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Para mostrar las estadisticas de una bliblioteca*/
    }
    
        static public void estadisticas_Biblioteca(ArrayList<bibliotecas> b){
        
        Scanner lector=new Scanner(System.in);
        System.out.println("======================");
        System.out.println("Indica la biblioteca ");
        System.out.println("----------------------");
        System.out.println("Introduce la ID de la biblioteca");
        int c=lector.nextInt();
        boolean encontrado=false;
        int i = 0;
        while ((i < b.size()) && (encontrado==false)) {
            if (b.get(i).getId()==c){
                System.out.println("La biblioteca existe, indica las caracteristicas de la persona");
                b.get(i).mostrar_Biblioteca();
                encontrado=true; 
            }else i++;            
        }
        if (encontrado==false){
            System.out.println("La biblioteca no existe"); 
        }   
        
        }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Para mostrar las estadisticas de todas las  bliblioteca*/        
        static public void estadisticasRedBibliotecas(ArrayList<bibliotecas> b){
            
          System.out.println("======================");
          System.out.println("Fichas de bibliotecas");
          System.out.println("======================");
          int i;
          for (i=0;i<b.size();i++){
              b.get(i).mostrar_Biblioteca();
          }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Consultar libro*/
        }   
        
        static public void consultar_Libro(ArrayList<bibliotecas> b){
        
            Scanner lector=new Scanner(System.in);
            System.out.println("======================");
            System.out.println("Mostrar libro ");
            System.out.println("----------------------");
            System.out.println("Introduce la ISBM del libro");
            int c=lector.nextInt();       
        }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Consultar libro biblioteca*/
        
        static public void consultar_LibroBiblioteca(ArrayList<bibliotecas> b){
       
            Scanner lector=new Scanner(System.in);
            System.out.println("======================");
            System.out.println("Mostrar libro en biblioteca");
            System.out.println("----------------------");
            System.out.println("Introduce la ISBM del libro");
            int o=lector.nextInt();
            System.out.println("Introduce el ID de la biblioteca");
            int c=lector.nextInt();
        }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Reservar libro*/
        static public void reservar_Libro(ArrayList<bibliotecas> b){
            
            Scanner lector=new Scanner(System.in);
            System.out.println("======================");
            System.out.println("Reservar libro");
            System.out.println("----------------------");
            System.out.println("Introduce la ISBM del libro");
            int o=lector.nextInt();
            System.out.println("Introduce el ID de la biblioteca");
            int c=lector.nextInt();
        
        }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*Devolver libro*/
        static public void devolver_Libro(ArrayList<bibliotecas> b){
        
            Scanner lector=new Scanner(System.in);
            System.out.println("======================");
            System.out.println("Devolver libro");
            System.out.println("----------------------");
            System.out.println("Introduce la ISBM del libro");
            int o=lector.nextInt();
            System.out.println("Introduce el ID de la biblioteca");
            int c=lector.nextInt();
        }               
}
