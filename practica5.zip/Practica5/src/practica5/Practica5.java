
package practica5;

import java.util.ArrayList;
import java.util.Scanner;

public class Practica5 {

    public static void main(String[] args) {
        int a =0;
        System.out.println("Que deseas hacer");
        System.out.println("1.Gestión administrativa");
        System.out.println("2.Utilidades usuario");


        Scanner sc = new Scanner(System.in);
        System.out.println("Elige una opción;");
        a = sc.nextInt();
            
            switch (a) {
                case 1:
                    System.out.println("1.Gestión administrativa");
                            int b =0;
                            System.out.println("Que deseas hacer");
                            System.out.println("1.Dar de alta biblioteca");
                            System.out.println("2.Dar de alta los libros a la bibioteca");
                            System.out.println("3.Dar de alta las personas a la bibioteca");
                            System.out.println("4.Estadisticas de una bibioteca");
                            System.out.println("5.Estadistica de la red de bibioteca");
                                    
                            System.out.println("Elige una opción;");
                            b = sc.nextInt();
                            ArrayList<bibliotecas> lista_bibliotecas = new ArrayList<>();
                                switch (b){
                                    case 1:
                                        System.out.println("1.Dar de alta biblioteca");
                                        lista_bibliotecas.add(bibliotecas.crear_Biblioteca());
                                        break;
                                    case 2:
                                        System.out.println("2.Dar de alta los libros a la bibioteca");
                                        bibliotecas.localizar_Biblioteca_libro(lista_bibliotecas);
                                        
                                         break;
                                    case 3:
                                        System.out.println("3.Dar de alta las personas a la bibioteca");
                                        bibliotecas.localizar_Biblioteca_persona(lista_bibliotecas);
                                        break;
                                    case 4:
                                        System.out.println("4.Estadisticas de una bibioteca");
                                        bibliotecas.estadisticas_Biblioteca(lista_bibliotecas);
                                        break;
                                    case 5:
                                        System.out.println("5.Estadistica de la red de bibioteca");
                                        bibliotecas.estadisticasRedBibliotecas(lista_bibliotecas);
                                        break;
                                }
                            
                    break;
                case 2:
                    System.out.println("2.Utilidades usuario");
                        int c =0;
                            System.out.println("Que deseas hacer");
                            System.out.println("1.Consultar libro");
                            System.out.println("2.Consultar libro biblioteca");
                            System.out.println("3.Reservar libro");
                            System.out.println("4.Devolver libro");
                                    
                            System.out.println("Elige una opción;");
                            c = sc.nextInt();
                            
                                switch (c){
                                    case 1:
                                        System.out.println("1.Consultar libro");
                                        break;
                                    case 2:
                                        System.out.println("2.Consultar libro biblioteca");
                                         break;
                                    case 3:
                                        System.out.println("3.Reservar libro");
                                        break;
                                    case 4:
                                        System.out.println("4.Devolver libro");
                                        break;
                                }
                    break;
             }
    }
}
